public interface LoanConstants {

    public int shortTermLoan = 3;
    public int midTermLoan = 7;
    public int longTermLoan = 15;
    public String companyName = "Java Programmers Loan Company";
    public double maxLoanAmount = 50000;

}